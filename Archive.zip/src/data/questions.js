const questions = [
  {
    question: "Hello world",
    answer: "Salom dunyo",
    words: ["olam", "do'st"],
  },
  {
    question: "It is a beautiful flower",
    answer: "Bu chiroyli gul",
    words: ["Ana u", "xunuk", "meva"],
  },
  {
    question: "I'm going to be a senior developer",
    answer: "Men senior dasturchi bo'lmoqchiman",
  },
];

export default questions;
